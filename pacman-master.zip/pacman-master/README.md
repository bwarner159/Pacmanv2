#### Pac-Man in JavaScript

Project for Web-dev course in University of Helsinki. Unfinished but playable.

No image files used for graphics.

Example game running on http://wesopeli.appspot.com
